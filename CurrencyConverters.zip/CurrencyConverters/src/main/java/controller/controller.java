package controller;

import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import model.ConversionRequest;
import model.CurrencyResponse;
import service.service;

@RestController
@RequestMapping("/api")
public class controller {
	@Autowired
	private service service;
	@GetMapping
	public ResponseEntity <Map<String, Double>>getrates(@RequestParam(defaultValue = "USD")String base){
		return ResponseEntity.ok(service.getExchangeRates(base));
	}
	@PostMapping("/convert")
	public ResponseEntity<ConversionResponse>convertCurrency(@RequestBody ConversionRequest request){
		double convertamount = service.conversionrequest(request.getFrom(),request.getTo(),request.getAmount());
		return ResponseEntity.ok(new CurrencyResponse(request.getFrom(),request.getTo(), request.getAmount(), convertamount));
	}
	

}
