package model;

public class CurrencyResponse {
	private String form;
	private String to;
	private double amount;
	private double convertamount;
	public CurrencyResponse(String form, String to, double amount, double convertamount) {
		super();
		this.form = form;
		this.to = to;
		this.amount = amount;
		this.convertamount = convertamount;
	}
	public String getForm() {
		return form;
	}
	public void setForm(String form) {
		this.form = form;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getConvertamount() {
		return convertamount;
	}
	public void setConvertamount(double convertamount) {
		this.convertamount = convertamount;
	}
	

}
