package model;

import java.util.Map;

public class Exchangerate {
	private Map<String, Double>rate;

	public Map<String, Double> getRate() {
		return rate;
	}

	public void setRate(Map<String, Double> rate) {
		this.rate = rate;
	}
	
	

}
