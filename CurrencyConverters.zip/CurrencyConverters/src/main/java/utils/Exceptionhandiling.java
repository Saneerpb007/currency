package utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class Exceptionhandiling {
	org.springframework.web.bind.annotation.ExceptionHandler(CurrencyNotFoundException.class)
	public ResponseEntity<String> handleCurrencyNotFound(CurrencyNotFountException ex){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	}
	org.springframework.web.bind.annotation.ExceptionHandler(ExternalException.class)
	public ResponseEntity<String> ExternalExceptionError(ExternalException ex){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	}
	org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
	public ResponseEntity<String> HandlerExceptionError(Exception ex){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	}
	

}
