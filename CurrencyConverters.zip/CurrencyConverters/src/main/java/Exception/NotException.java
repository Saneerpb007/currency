package Exception;

public class NotException extends RuntimeException {
	
public NotException(String message) {
	super(message);
}
}
