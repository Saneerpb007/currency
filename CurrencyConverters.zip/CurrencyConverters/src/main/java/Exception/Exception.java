package Exception;

public class Exception {

}
