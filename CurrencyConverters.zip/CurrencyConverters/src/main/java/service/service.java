package service;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class service {
	private static final String API_URl="http://api.exchange-api.com/vi/latest";
	private final RestTemplate restTemplate=new RestTemplate();

	public Map<String, Double>getExchangeRates (String base) {
    String url=API_URL + base;

	try {
		ExchangeRateResponse response=restTemplate.getForObject(url, ExchangeRateResponse.class);
				if (response==null || response.getRates() == null) {
				}
		
	throw new ExternalApiException("Failed to fetch exchange rates. Please try again late:"+e.getMessage());
	}
	return response.getRates();

	} catch (Exception e) {

	throw new ExternalApiException("Error connecting to external API: " + e.getMessage());

	}
	}
}

	public double convertCurrency (String from, String to, double amount) {

	Map<String, Double> rates=getExchangeRates (from);

	if (!rates.containsKey(to)) {
		throw new Exception("Invalid currency code: " + to);
	}
	return amount * rates.get(to);
	
	}
}
